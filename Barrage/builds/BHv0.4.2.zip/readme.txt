1. Unzip the folder this file is in
2. Run "Barrage.exe"
3. To change the patterns, go to "spawnPatterns.txt"
	-refer to spawnInfo.txt for help
	-there is also a "presets.txt" for samples

Controls are:
arrow keys	movement
left shift	slow
r		restart
esc		pause