1. Unzip the folder this file is in
2. Run "Barrage.exe"
3. To change the patterns, go to "spawnPatterns.txt"
	-refer to spawnInfo.txt for help
	-there is also a "presets.txt" for samples
4. There is an in-game editor. Currently there are many issues with it.

Controls are:
arrow keys	movement
left shift	slow
r		restart
esc		pause

Editor:
k		play/pause
l		step forwards
j		step backwards
h		large step backwards